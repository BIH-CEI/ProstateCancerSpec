# Prostatastanze 05 - Rechts medial mid - Prostate Cancer Specification v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Prostatastanze 05 - Rechts medial mid**

## Example Specimen: Prostatastanze 05 - Rechts medial mid

Profiles: [MII PR Patho Specimenversion: null2026.0.0)](https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.patho@2026.0.0&canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-patho/StructureDefinition/mii-pr-patho-specimen), [MII PR Biobank Specimen Bioprobe Coreversion: null2026.0.0)](https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.onkologie@2026.0.0&canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/SpecimenCore)

> **MII EX Biobank Feature R5**
* type: Structure of middle regional part of transition zone of right half prostate (body structure)
* description: Markiert mit oranger Tinte

**identifier**: Placer Identifier/BX24_001_05_A, Filler Identifier/E2024_001-05-A

**accessionIdentifier**: `https://pathologie.example-hospital.de/fhir/fn/befundbericht`/E2024_001

**status**: Available

**type**: Prostate tru-cut biopsy sample

**subject**: [Hans Mueller Male, DoB: 1955-08-15 ( http://example.hospital.de/patient-ids#PAT-2024-001)](Patient-Patient1.md)

**request**: [ServiceRequest Tru-cut biopsy of prostate (procedure)](ServiceRequest-CoreNeedleBiopsyRequest.md)

### Collections

| | | | | |
| :--- | :--- | :--- | :--- | :--- |
| - | **Collector** | **Collected[x]** | **Method** | **BodySite** |
| * | [Practitioner Andreas Weber](Practitioner-UrologistPractitioner.md) | 2024-01-15 10:38:00+0100 | Tru-cut biopsy of prostate (procedure) | Structure of middle regional part of transition zone of right half prostate (body structure) |

### Containers

| | |
| :--- | :--- |
| - | **Type** |
| * | Specimen vial (physical object) |



## Resource Content

```json
{
  "resourceType" : "Specimen",
  "id" : "CoreNeedleBiopsySpecimen05Part",
  "meta" : {
    "profile" : [
      "https://www.medizininformatik-initiative.de/fhir/ext/modul-patho/StructureDefinition/mii-pr-patho-specimen|2026.0.0",
      "https://www.medizininformatik-initiative.de/fhir/ext/modul-biobank/StructureDefinition/SpecimenCore|2026.0.0"
    ]
  },
  "extension" : [
    {
      "extension" : [
        {
          "url" : "type",
          "valueCodeableConcept" : {
            "coding" : [
              {
                "system" : "http://snomed.info/sct",
                "code" : "716911004",
                "display" : "Structure of middle regional part of transition zone of right half prostate (body structure)"
              }
            ]
          }
        },
        {
          "url" : "description",
          "valueString" : "Markiert mit oranger Tinte"
        }
      ],
      "url" : "http://hl7.org/fhir/5.0/StructureDefinition/extension-Specimen.feature"
    }
  ],
  "identifier" : [
    {
      "type" : {
        "coding" : [
          {
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "PLAC"
          }
        ]
      },
      "system" : "https://pathologie.example-hospital.de/fhir/fn/untersuchungsauftrag",
      "value" : "BX24_001_05_A"
    },
    {
      "type" : {
        "coding" : [
          {
            "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
            "code" : "FILL"
          }
        ]
      },
      "system" : "https://pathologie.example-hospital.de/fhir/fn/befundbericht",
      "value" : "E2024_001-05-A"
    }
  ],
  "accessionIdentifier" : {
    "system" : "https://pathologie.example-hospital.de/fhir/fn/befundbericht",
    "value" : "E2024_001"
  },
  "status" : "available",
  "type" : {
    "coding" : [
      {
        "system" : "http://snomed.info/sct",
        "code" : "309134005",
        "display" : "Prostate tru-cut biopsy sample"
      }
    ]
  },
  "subject" : {
    "reference" : "Patient/Patient1"
  },
  "request" : [
    {
      "reference" : "ServiceRequest/CoreNeedleBiopsyRequest"
    }
  ],
  "collection" : {
    "collector" : {
      "reference" : "Practitioner/UrologistPractitioner"
    },
    "collectedDateTime" : "2024-01-15T10:38:00+01:00",
    "method" : {
      "coding" : [
        {
          "system" : "http://snomed.info/sct",
          "code" : "301759007",
          "display" : "Tru-cut biopsy of prostate (procedure)"
        }
      ]
    },
    "bodySite" : {
      "coding" : [
        {
          "system" : "http://snomed.info/sct",
          "code" : "716911004",
          "display" : "Structure of middle regional part of transition zone of right half prostate (body structure)"
        }
      ]
    }
  },
  "container" : [
    {
      "type" : {
        "coding" : [
          {
            "system" : "http://snomed.info/sct",
            "code" : "434746001",
            "display" : "Specimen vial (physical object)"
          }
        ]
      }
    }
  ]
}

```
