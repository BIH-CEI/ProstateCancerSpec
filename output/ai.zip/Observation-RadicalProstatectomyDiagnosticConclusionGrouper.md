# Diagnostic Conclusion Grouper - Prostatectomy - Prostate Cancer Specification v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Diagnostic Conclusion Grouper - Prostatectomy**

## Example Observation: Diagnostic Conclusion Grouper - Prostatectomy

Profile: [MII PR Patho Diagnostic Conclusion Grouper](https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.patho@2026.0.0&canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-patho/StructureDefinition/mii-pr-patho-diagnostic-conclusion-grouper) version: 2026.0.0

**basedOn**: [ServiceRequest Pathology synoptic report](ServiceRequest-RadicalProstatectomyReportRequest.md)

**status**: Final

**category**: Laboratory

**code**: Pathology report final diagnosis Narrative

**subject**: [Hans Mueller Male, DoB: 1955-08-15 ( http://example.hospital.de/patient-ids#PAT-2024-001)](Patient-Patient1.md)

**effective**: 2024-03-20

**performer**: [Practitioner Maria Schneider ](Practitioner-PathologistPractitioner.md)

**hasMember**: 

* [Observation Histology and Behavior ICD-O-3 Cancer](Observation-RadicalProstatectomyHistologicalTypeICDO3.md)
* [Observation Histology type in Cancer specimen Narrative](Observation-RadicalProstatectomyMorphologyFreeText.md)
* [Observation World Health Organization tumor classification (observable entity)](Observation-RadicalProstatectomyICDOVersion.md)
* [Observation Gleason pattern.primary in Prostate tumor](Observation-RadicalProstatectomyPrimaryGleasonPattern.md)
* [Observation Gleason pattern.secondary in Prostate tumor](Observation-RadicalProstatectomySecondaryGleasonPattern.md)
* [Observation Gleason score in Specimen Qualitative](Observation-RadicalProstatectomyGleasonScoreTotal.md)
* [Observation Prostate tumor area with Gleason pattern 4+5/Total tumor area [Area Fraction] in Prostate tumor by Microscopy](Observation-RadicalProstatectomyPercentageGleason45.md)
* [Observation Histologic grade of primary malignant neoplasm of prostate by International Society of Urological Pathology technique (observable entity)](Observation-RadicalProstatectomyGradingGroupISUP.md)
* [Observation Non-infiltrating intraductal carcinoma (morphologic abnormality)](Observation-RadicalProstatectomyIntraductalCarcinoma.md)
* [Observation Cribriform carcinoma](Observation-RadicalProstatectomyInvasiveCribriformCarcinoma.md)
* [Observation Size.maximum dimension in Tumor](Observation-RadicalProstatectomyMaxTumorDiameter.md)
* [Observation Tissue involved by tumor in Prostate tumor](Observation-RadicalProstatectomyProstaticTissueInvolved.md)
* [Observation Periprostatic fat invasion [Identifier] in Specimen by CAP cancer protocols](Observation-RadicalProstatectomyExtraprostaticExtension.md)
* [Observation Seminal vesicle invasion [Identifier] in Specimen by CAP cancer protocols](Observation-RadicalProstatectomySeminalVesicleInvasion.md)
* [Observation Venous + Lymphatic small vessel invasion in Specimen by CAP cancer protocols](Observation-RadicalProstatectomyLymphovascularInvasion.md)
* [Observation Perineural invasion [Presence] in Cancer specimen](Observation-RadicalProstatectomyPerineuralInfiltration.md)
* [Observation Bladder neck involvement of Prostate tumor](Observation-RadicalProstatectomyBladderNeckInvasion.md)
* [Observation Margin involvement [Type] in Prostate tumor](Observation-RadicalProstatectomyMarginStatus.md)
* [Observation Regional lymph nodes examined [#] Specimen](Observation-RadicalProstatectomyLymphNodesExamined.md)
* [Observation Regional lymph nodes positive [#] Specimen](Observation-RadicalProstatectomyLymphNodesPositive.md)
* [Observation Primary tumor.pathology Cancer](Observation-RadicalProstatectomyTNMpT.md)
* [Observation Regional lymph nodes.pathology [Class] Cancer](Observation-RadicalProstatectomyTNMpN.md)

**derivedFrom**: [Response to Questionnaire 'https://art-decor.org/fhir/Questionnaire/2.16.840.1.113883.3.1937.777.18.27.19--20250115134435' about '->Hans Mueller Male, DoB: 1955-08-15 ( http://example.hospital.de/patient-ids#PAT-2024-001)'](QuestionnaireResponse-QuestionnaireResponseRadicalProstatectomy.md)



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "RadicalProstatectomyDiagnosticConclusionGrouper",
  "meta" : {
    "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-patho/StructureDefinition/mii-pr-patho-diagnostic-conclusion-grouper|2026.0.0"]
  },
  "basedOn" : [{
    "reference" : "ServiceRequest/RadicalProstatectomyReportRequest"
  }],
  "status" : "final",
  "category" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
      "code" : "laboratory"
    }]
  }],
  "code" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "22637-3"
    }]
  },
  "subject" : {
    "reference" : "Patient/Patient1"
  },
  "effectiveDateTime" : "2024-03-20",
  "performer" : [{
    "reference" : "Practitioner/PathologistPractitioner"
  }],
  "hasMember" : [{
    "reference" : "Observation/RadicalProstatectomyHistologicalTypeICDO3"
  },
  {
    "reference" : "Observation/RadicalProstatectomyMorphologyFreeText"
  },
  {
    "reference" : "Observation/RadicalProstatectomyICDOVersion"
  },
  {
    "reference" : "Observation/RadicalProstatectomyPrimaryGleasonPattern"
  },
  {
    "reference" : "Observation/RadicalProstatectomySecondaryGleasonPattern"
  },
  {
    "reference" : "Observation/RadicalProstatectomyGleasonScoreTotal"
  },
  {
    "reference" : "Observation/RadicalProstatectomyPercentageGleason45"
  },
  {
    "reference" : "Observation/RadicalProstatectomyGradingGroupISUP"
  },
  {
    "reference" : "Observation/RadicalProstatectomyIntraductalCarcinoma"
  },
  {
    "reference" : "Observation/RadicalProstatectomyInvasiveCribriformCarcinoma"
  },
  {
    "reference" : "Observation/RadicalProstatectomyMaxTumorDiameter"
  },
  {
    "reference" : "Observation/RadicalProstatectomyProstaticTissueInvolved"
  },
  {
    "reference" : "Observation/RadicalProstatectomyExtraprostaticExtension"
  },
  {
    "reference" : "Observation/RadicalProstatectomySeminalVesicleInvasion"
  },
  {
    "reference" : "Observation/RadicalProstatectomyLymphovascularInvasion"
  },
  {
    "reference" : "Observation/RadicalProstatectomyPerineuralInfiltration"
  },
  {
    "reference" : "Observation/RadicalProstatectomyBladderNeckInvasion"
  },
  {
    "reference" : "Observation/RadicalProstatectomyMarginStatus"
  },
  {
    "reference" : "Observation/RadicalProstatectomyLymphNodesExamined"
  },
  {
    "reference" : "Observation/RadicalProstatectomyLymphNodesPositive"
  },
  {
    "reference" : "Observation/RadicalProstatectomyTNMpT"
  },
  {
    "reference" : "Observation/RadicalProstatectomyTNMpN"
  }],
  "derivedFrom" : [{
    "reference" : "QuestionnaireResponse/QuestionnaireResponseRadicalProstatectomy"
  }]
}

```
