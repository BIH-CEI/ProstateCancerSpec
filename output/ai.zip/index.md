# Prostate Cancer Specification - Prostate Cancer Specification v0.1.0

* [**Table of Contents**](toc.md)
* **Prostate Cancer Specification**

## Prostate Cancer Specification

| | |
| :--- | :--- |
| *Official URL*:http://prostatecancerspec.org/ImplementationGuide/prostatecancerspec | *Version*:0.1.0 |
| Draft as of 2026-05-17 | *Computable Name*:ProstateCancerSpec |

This Implementation Guide defines FHIR examples for prostate cancer pathology reporting based on the German Medical Informatics Initiative (MII) core datasets for pathology and oncology.

### Scope and Purpose

This IG provides structured data models and comprehensive examples for prostate cancer pathology workflows, including:

* **Diagnostic Procedures**: Core Needle Biopsy, TUR-P resection, enucleation, and radical prostatectomy
* **Specimen Management**: Complete specimen hierarchies from parts to blocks to slides
* **Macroscopic Findings**: Tissue measurements, weight, and visual characteristics
* **Microscopic Findings**: Detailed histological observations (biopsy only)
* **Diagnostic Conclusions**: Gleason scoring, ISUP grading, tumor quantification, invasion patterns
* **Structured Reports**: DiagnosticReport and Composition resources for complete pathology reports

### Example Scenarios

This IG includes four comprehensive example scenarios representing different clinical contexts:

#### Core Needle Biopsy

Complete 12-core prostate biopsy with:

* 12 specimen locations (Part → Block → Slide for each)
* Macroscopic findings (length, cylinder count, laterality per core)
* Microscopic findings (detailed histological observations per core)
* Diagnostic conclusion with Gleason scoring and quantification

#### Radical Prostatectomy

Complete prostate specimen from radical prostatectomy showing:

* Favorable cancer case: Gleason 3+4=7 (ISUP Grade Group 2)
* Complete prostate specimen with 3 blocks and 6 slides
* Macroscopic findings including organ dimensions and seminal vesicles
* Diagnostic conclusion with negative margins (R0), no extraprostatic extension
* TNM staging: pT2c pN0

#### Transurethral Enucleation

Prostate enucleation (simple prostatectomy) with incidental aggressive cancer:

* High-grade cancer: Gleason 4+5=9 (ISUP Grade Group 5)
* 5 blocks and 10 slides from enucleated tissue
* Extensive tumor involvement (60% of tissue)
* Present: intraductal carcinoma, invasive cribriform carcinoma, extraprostatic extension, seminal vesicle invasion

#### Transurethral Resection

Transurethral resection (TUR-P) with benign findings:

* Benign prostatic hyperplasia (BPH), no carcinoma
* 5 blocks and 10 slides from TUR chips
* Macroscopic and diagnostic findings from resection tissue

### Structure of the Scenarios

The diagram above uses the Core Needle Biopsy scenario as a representative example. The other scenarios (Radical Prostatectomy, Transurethral Enucleation, Transurethral Resection) follow an analogous structure, differing primarily in the number and type of specimens, the applicable microscopic findings, and the diagnostic conclusion observations.

### Resource Organization

Each example scenario is organized with the following structure:

1. **ServiceRequest**: Initial pathology request
1. **Specimens**: Complete specimen hierarchy (Part → Blocks → Slides)
1. **MacroscopyGrouper**: Grouper observation referencing all macroscopic findings
1. **MicroscopyGrouper**: Grouper observation for microscopic findings (biopsy only)
1. **DiagnosticConclusionGrouper**: Grouper observation referencing all diagnostic conclusion findings
1. **DiagnosticReport**: Complete pathology report tying together all observations
1. **Composition**: FHIR document structure for the complete report

#### Dependencies

This IG builds upon:

* **MII Pathology Module** [de.medizininformatikinitiative.kerndatensatz.patho v2026.0.0](https://simplifier.net/packages/de.medizininformatikinitiative.kerndatensatz.patho/2026.0.0): Grouper and Finding Observations, ServiceRequests and DiagnosticReports

and also assures the compatibility to:

* **MII Oncology Module** [de.medizininformatikinitiative.kerndatensatz.onkologie v2026.0.0](https://simplifier.net/packages/de.medizininformatikinitiative.kerndatensatz.onkologie) : Observations for TNM staging, Gleason grading profiles (harmonized), PSA-Level etc.
* **MII Base Module** [de.medizininformatikinitiative.kerndatensatz.base v2026.0.0](https://simplifier.net/packages/de.medizininformatikinitiative.kerndatensatz.base): Core patient and procedure profiles
* **MII Biobank Module** [de.medizininformatikinitiative.kerndatensatz.biobank v2026.0.0](https://simplifier.net/packages/de.medizininformatikinitiative.kerndatensatz.biobank): Specimens (inherited in patho)

#### Pathology Reporting Basis

The pathology findings and observations in this IG are based on the prostate cancer datasets published by the **International Collaboration on Cancer Reporting (ICCR)**. These internationally agreed, evidence-based datasets define which elements should be reported in structured pathology reports for prostate cancer specimens:

* **[Prostate Cancer – Core Needle Biopsy, 2nd edition (November 2024)](https://www.iccr-cancer.org/datasets/published-datasets/urinary-male-genital/prostate-biopsy/)**: Histopathology reporting guide for core needle biopsies, covering specimen-level and case-level reporting elements.
* **[Prostate Cancer – Radical Prostatectomy Specimen, 3rd edition (November 2024)](https://www.iccr-cancer.org/datasets/published-datasets/urinary-male-genital/prostate-rad-pros/)**: Histopathology reporting guide for radical prostatectomy specimens.
* **[Prostate Cancer – Transurethral Resection and Enucleation, 2nd edition (November 2024)](https://www.iccr-cancer.org/datasets/published-datasets/urinary-male-genital/prostate-tur/)**: Histopathology reporting guide for TUR and enucleation specimens.

All three datasets were updated in 2024 to align with the 2022 WHO Classification of Urinary and Male Genital Tumours (5th edition) and TNM8 staging.

#### Standards Compliance

* **FHIR R4** (4.0.1)
* **LOINC** codes for laboratory values, pathology observations, and Gleason scoring
* **SNOMED CT** for clinical terminology, histological findings, and anatomical locations
* **ICD-O-3** for histological tumor type classification
* **ICD-10-GM** for diagnoses
* **TNM Classification** for cancer staging

#### Key Features

* **Complete Specimen Hierarchies**: All examples include complete specimen traceability from tissue parts through blocks to individual slides
* **Grouper Pattern**: Uses MII Pathology Grouper pattern to organize findings into macroscopic, microscopic (where applicable), and diagnostic conclusion sections
* **Comprehensive Coding**: All observations include appropriate LOINC and SNOMED CT codes
* **Real-world Scenarios**: Examples represent actual clinical workflows and findings
* **Progressive Severity**: Examples range from favorable (prostatectomy) to aggressive (enucleation) cancer presentations

