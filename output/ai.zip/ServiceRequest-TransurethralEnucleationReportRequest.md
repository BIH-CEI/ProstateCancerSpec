# Prostata Enucleation Anforderung - Prostate Cancer Specification v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Prostata Enucleation Anforderung**

## Example ServiceRequest: Prostata Enucleation Anforderung

Profile: [MII PR Patho Service Requestversion: null2026.0.0)](https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.patho@2026.0.0&canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-patho/StructureDefinition/mii-pr-patho-service-request)

**identifier**: Placer Identifier/PATH-RPT-2024-004

**status**: Completed

**intent**: Order

**category**: Pathology consultation, comprehensive, records and specimen with report (procedure)

**code**: Prostatectomy (procedure)

**subject**: [Klaus Becker Male, DoB: 1958-11-10 ( http://example.hospital.de/patient-ids#PAT-2024-003)](Patient-Patient3.md)

**encounter**: [Encounter: identifier = http://example.hospital.de/encounters#E_24_004; status = finished; class = IMP (IMP)](Encounter-TransurethralEnucleationEncounter.md)

**requester**: [Practitioner Andreas Weber ](Practitioner-UrologistPractitioner.md)

**performer**: [Practitioner Maria Schneider ](Practitioner-PathologistPractitioner.md)

**reasonCode**: Benign prostatic hyperplasia

**supportingInfo**: 

* [Observation Prostate specific Ag [Mass/volume] in Serum or Plasma](Observation-TransurethralEnucleationPSAPre.md)
* [Procedure Enukleation der Prostata](Procedure-TransurethralEnucleationProcedure.md)
* [Condition Prostatahyperplasie ohne Beschwerden beim Wasserlassen](Condition-TransurethralEnucleationDiagnosisBPH.md)

**specimen**: [Specimen: identifier = Placer Identifier,Filler Identifier; accessionIdentifier = https://pathologie.example-hospital.de/fhir/fn/befundbericht#E_24_004; status = available; type = Tissue specimen](Specimen-TransurethralEnucleationSpecimenPart.md)



## Resource Content

```json
{
  "resourceType" : "ServiceRequest",
  "id" : "TransurethralEnucleationReportRequest",
  "meta" : {
    "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-patho/StructureDefinition/mii-pr-patho-service-request|2026.0.0"]
  },
  "identifier" : [{
    "type" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v2-0203",
        "code" : "PLAC",
        "display" : "Placer Identifier"
      }]
    },
    "system" : "http://example.hospital.de/serviceRequest",
    "value" : "PATH-RPT-2024-004"
  }],
  "status" : "completed",
  "intent" : "order",
  "category" : [{
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "726007",
      "display" : "Pathology consultation, comprehensive, records and specimen with report (procedure)"
    }]
  }],
  "code" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "90470006",
      "display" : "Prostatectomy (procedure)"
    }]
  },
  "subject" : {
    "reference" : "Patient/Patient3"
  },
  "encounter" : {
    "reference" : "Encounter/TransurethralEnucleationEncounter"
  },
  "requester" : {
    "reference" : "Practitioner/UrologistPractitioner"
  },
  "performer" : [{
    "reference" : "Practitioner/PathologistPractitioner"
  }],
  "reasonCode" : [{
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "266569009",
      "display" : "Benign prostatic hyperplasia"
    }]
  }],
  "supportingInfo" : [{
    "reference" : "Observation/TransurethralEnucleationPSAPre"
  },
  {
    "reference" : "Procedure/TransurethralEnucleationProcedure"
  },
  {
    "reference" : "Condition/TransurethralEnucleationDiagnosisBPH"
  }],
  "specimen" : [{
    "reference" : "Specimen/TransurethralEnucleationSpecimenPart"
  }]
}

```
