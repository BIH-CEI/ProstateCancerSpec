# Makroskopische Befunde Grouper Prostatektomie - Prostate Cancer Specification v0.1.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Makroskopische Befunde Grouper Prostatektomie**

## Example Observation: Makroskopische Befunde Grouper Prostatektomie

Profile: [MII PR Patho Macroscopic Grouper](https://simplifier.net/resolve?scope=de.medizininformatikinitiative.kerndatensatz.patho@2026.0.0&canonical=https://www.medizininformatik-initiative.de/fhir/ext/modul-patho/StructureDefinition/mii-pr-patho-macroscopic-grouper) version: 2026.0.0

**status**: Final

**category**: Laboratory

**code**: Pathology report gross observation Narrative

**subject**: [Hans Mueller Male, DoB: 1955-08-15 ( http://example.hospital.de/patient-ids#PAT-2024-001)](Patient-Patient1.md)

**effective**: 2024-03-16 14:00:00+0100

**performer**: [Practitioner Maria Schneider ](Practitioner-PathologistPractitioner.md)

**value**: Makroskopische Messungen des Prostatektomiepräparats

**bodySite**: Prostate

**hasMember**: 

* [Observation Weight of Tissue](Observation-RadicalProstatectomyMacroscopicProstateWeight.md)
* [Observation Dimension [Length] of Specimen](Observation-RadicalProstatectomyMacroscopicProstateWidth.md)
* [Observation Dimension [Length] of Specimen](Observation-RadicalProstatectomyMacroscopicProstateHeight.md)
* [Observation Dimension [Length] of Specimen](Observation-RadicalProstatectomyMacroscopicProstateDepth.md)
* [Observation Tumor finding](Observation-RadicalProstatectomyMacroscopicLymphNodesPresent.md)
* [Observation Anatomic part Laterality](Observation-RadicalProstatectomyMacroscopicLymphNodesLaterality.md)
* [Observation Seminal vesicles [Presence] in Specimen](Observation-RadicalProstatectomyMacroscopicSeminalVesiclesPresent.md)
* [Observation Dimension [Length] of Specimen](Observation-RadicalProstatectomyMacroscopicSeminalVesicleLength.md)

**derivedFrom**: [Response to Questionnaire 'https://art-decor.org/fhir/Questionnaire/2.16.840.1.113883.3.1937.777.18.27.19--20250115134435' about '->Hans Mueller Male, DoB: 1955-08-15 ( http://example.hospital.de/patient-ids#PAT-2024-001)'](QuestionnaireResponse-QuestionnaireResponseRadicalProstatectomy.md)



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "RadicalProstatectomyMacroscopicGrouper",
  "meta" : {
    "profile" : ["https://www.medizininformatik-initiative.de/fhir/ext/modul-patho/StructureDefinition/mii-pr-patho-macroscopic-grouper|2026.0.0"]
  },
  "status" : "final",
  "category" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
      "code" : "laboratory"
    }]
  }],
  "code" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "22634-0"
    }]
  },
  "subject" : {
    "reference" : "Patient/Patient1"
  },
  "effectiveDateTime" : "2024-03-16T14:00:00+01:00",
  "performer" : [{
    "reference" : "Practitioner/PathologistPractitioner"
  }],
  "valueString" : "Makroskopische Messungen des Prostatektomiepräparats",
  "bodySite" : {
    "coding" : [{
      "system" : "http://snomed.info/sct",
      "code" : "41216001",
      "display" : "Prostate"
    }]
  },
  "hasMember" : [{
    "reference" : "Observation/RadicalProstatectomyMacroscopicProstateWeight"
  },
  {
    "reference" : "Observation/RadicalProstatectomyMacroscopicProstateWidth"
  },
  {
    "reference" : "Observation/RadicalProstatectomyMacroscopicProstateHeight"
  },
  {
    "reference" : "Observation/RadicalProstatectomyMacroscopicProstateDepth"
  },
  {
    "reference" : "Observation/RadicalProstatectomyMacroscopicLymphNodesPresent"
  },
  {
    "reference" : "Observation/RadicalProstatectomyMacroscopicLymphNodesLaterality"
  },
  {
    "reference" : "Observation/RadicalProstatectomyMacroscopicSeminalVesiclesPresent"
  },
  {
    "reference" : "Observation/RadicalProstatectomyMacroscopicSeminalVesicleLength"
  }],
  "derivedFrom" : [{
    "reference" : "QuestionnaireResponse/QuestionnaireResponseRadicalProstatectomy"
  }]
}

```
