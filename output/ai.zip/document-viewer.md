# Befund-Viewer - Prostate Cancer Specification v0.1.0

* [**Table of Contents**](toc.md)
* **Befund-Viewer**

## Befund-Viewer

Laden Sie ein FHIR Document Bundle (JSON) um den menschenlesbaren Befund anzuzeigen, oder wählen Sie eines der vorhandenen Beispiele:

**Beispiel-Dokument:**

-- Bitte wählen --
Stanzbiopsie (Core Needle Biopsy)
Radikale Prostatektomie
TUR-Prostata (benigne)
Prostata-Enukleation
oder

**Noch kein Dokument geladen.**

